The README.txt in the main commerce_feeds directory has instructions on how
to use this feature to demonstrate imports.

In addition to the provided example_products.csv, larger feeds are available
on http://d7.randyfay.com.