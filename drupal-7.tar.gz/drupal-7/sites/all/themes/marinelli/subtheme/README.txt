**** Marinelli base subtheme ****

read carefully the handbook page on drupal.org

http://drupal.org/node/1000284
